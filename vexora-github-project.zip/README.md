# ⚡ Vexora Video Engine

A real browser-based video cutting application that runs inside the user's browser via WebAssembly (FFmpeg.wasm).

## 🚀 Deployment to GitHub Pages
1. Go to GitHub and create a new repository.
2. Upload the `index.html` file.
3. Go to **Settings** > **Pages**.
4. Choose the `main` branch and click **Save**.
